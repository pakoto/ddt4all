#/bin/sh


xgettext -f python_files_Linux.txt -o ../locale/ddt4all.pot --from-code=UTF-8
